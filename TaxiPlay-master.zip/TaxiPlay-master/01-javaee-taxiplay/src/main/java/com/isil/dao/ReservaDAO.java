package com.isil.dao;

import com.isil.model.Reserva;

public interface ReservaDAO extends DAO <Reserva, Reserva.IdReserva> {
}
